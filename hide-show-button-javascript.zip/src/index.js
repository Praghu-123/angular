import "./styles.css";
//this works everywhere, junt not usual view of it
window.myFunction = function() {
  var x = document.getElementById("myDIV");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
};

console.log("hello");
